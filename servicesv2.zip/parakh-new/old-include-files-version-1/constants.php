<?php
//Constants to connect with the database
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'root');
define('DB_HOST', 'localhost');
define('DB_NAME', 'parakh');
define('SALT', 'parakh-revamp-local-key-2016');
